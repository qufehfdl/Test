package Service;

import java.util.Scanner;

import DB.data;

public class insert {
	
	public static String insertSubject() {
		System.out.println("글 제목 :");
		Scanner sub = new Scanner(System.in);
		String subject = sub.nextLine();
		return subject;
	}

	public static String insertContent() {
		System.out.println("글 내용 :");
		Scanner con = new Scanner(System.in);
		String content = con.nextLine();
		return content;
	}

	public static String insertWriter() {
		System.out.println("글 작성자 :");
		Scanner wri = new Scanner(System.in);
		String writer = wri.nextLine();
		return writer;
	}

}
