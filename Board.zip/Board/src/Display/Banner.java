package Display;

public class Banner {
	
	public static void banner(String ver) {
		System.out.println("◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆");
		System.out.println("◆◆◆◆◆◆◆◆◆◆◆ 게시판 "+ver+"버전 ◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆");
		System.out.println("◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆");
	}
}
