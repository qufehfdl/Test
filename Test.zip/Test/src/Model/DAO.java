package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAO {

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taehwa", "root", "1042");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	// 글저장 메서드
	public void insertBoard(bean b) {
		getCon();
		try {
			String sql = "insert into board1(subject,writer,date,content) values(?,?,now(),?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, b.getSubject());
			pstmt.setString(2, b.getWriter());
			pstmt.setString(3, b.getContent());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 글목록 메서드
	public ArrayList<bean> boardList() {
		getCon();
		ArrayList<bean> aList = new ArrayList<>();
		try {
			String sql = "select * from board1";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bean b = new bean();
				b.setNum(rs.getInt(1));
				b.setSubject(rs.getString(2));
				b.setWriter(rs.getString(3));
				b.setDate(rs.getString(4));
				b.setContent(rs.getString(5));
				aList.add(b);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return aList;
	}

	// 글 읽기 메서드
	public String content(int num) {
		getCon();
		String content = "";
		try {
			String sql = "select content from board1 where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				content = rs.getString(1);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}

	// 글 수정 메서드
	public void update(int num, String content) {
		getCon();
		try {
			String sql = "update board1 set content=? where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, content);
			pstmt.setInt(2, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 글 삭제 메서드
	public void delete(int num) {
		getCon();
		try {
			String sql = "delete from board1 where num=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
