/**
 * 
 */
/**
 * @author hth19
 *
 */
module Test {
	requires java.sql;
}