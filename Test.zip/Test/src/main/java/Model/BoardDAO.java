package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import oracle.net.aso.p;

public class BoardDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taehwa", "root", "1042");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 전체 게시글을 받아오는 메서드
	public Vector<BoardBean> allBoard(int startRow) {
		getCon();
		Vector<BoardBean> v = new Vector<>();
		try {
			String sql = "select * from board order by num desc limit ?,10";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow-1);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardBean bean = new BoardBean();
				bean.setNum(rs.getInt(1));
				bean.setId(rs.getString(2));
				bean.setSubject(rs.getString(3));
				bean.setContent(rs.getString(4));
				bean.setDate(rs.getString(5));
				bean.setReadCount(rs.getInt(6));
				bean.setRef(rs.getInt(7));
				v.add(bean);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}

	// 글쓰기
	public void insertBoard(BoardBean b) {
		int ref = 0;
		int restep = 1;
		int relevel = 1;
		getCon();
		try {
			String refsql = "select max(ref) from board";
			pstmt = con.prepareStatement(refsql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ref = rs.getInt(1) + 1;
			}
			String sql = "insert into board(id,subject,content,date,readcount,ref) values(?,?,?,now(),0,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, b.getId());
			pstmt.setString(2, b.getSubject());
			pstmt.setString(3, b.getContent());
			pstmt.setInt(4, ref);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 한 게시글의 정보
	public BoardBean BoardInfo(int num) {
		getCon();
		BoardBean b = new BoardBean();
		try {
			// 조회수 증가
			String readsql = "update board set readcount = readcount+1 where num=?";
			pstmt = con.prepareStatement(readsql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			String sql = "select * from board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				b.setNum(rs.getInt(1));
				b.setId(rs.getString(2));
				b.setSubject(rs.getString(3));
				b.setContent(rs.getString(4));
				b.setDate(rs.getString(5));
				b.setReadCount(rs.getInt(6));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	// 글 수정
	public void updateBoard(BoardBean b) {
		getCon();
		try {
			String sql = "update board set subject=?,content=? where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, b.getSubject());
			pstmt.setString(2, b.getContent());
			pstmt.setInt(3, b.getNum());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 글 삭제
	public void deleteBoard(int num) {
		getCon();
		try {
			String sql = "delete from board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 검색
	public Vector<BoardBean> search(String search) {
		getCon();
		Vector<BoardBean> v = new Vector<>();
		try {
			String sql = "select * from board NATURAL join member where subject like '%" + search
					+ "%' order by ref desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardBean b = new BoardBean();
				b.setId(rs.getString(1));
				b.setNum(rs.getInt(2));
				b.setSubject(rs.getString(3));
				b.setDate(rs.getString(5));
				b.setReadCount(rs.getInt(6));
				b.setRef(rs.getInt(7));
				v.add(b);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}

	public int getAllCount() {
		getCon();

		// 게시글 전체수를 저장하는 변수
		int count = 0;

		try {
			String sql = "select count(*) from board";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				// 전체 게시글수 리턴
				count = rs.getInt(1);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

}
