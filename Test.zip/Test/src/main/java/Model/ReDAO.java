package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import org.apache.tomcat.dbcp.dbcp2.PStmtKey;

import oracle.net.aso.b;

public class ReDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taehwa", "root", "1042");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 댓글을 저장
	public void insertRe(String recontent ,int num) {
		int rref = 0;
		int restep = 1;
		int relevel = 1;
		getCon();
		try {
			String refsql = "select max(rref) from re";
			pstmt = con.prepareStatement(refsql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				rref = rs.getInt(1) + 1;
			}
			String sql = "insert into re(recontent,redate,rref,restep,relevel,boardnum) values(?,now(),?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, recontent);
			pstmt.setInt(2, rref);
			pstmt.setInt(3, restep);
			pstmt.setInt(4, relevel);
			pstmt.setInt(5, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
 
	// 대댓글을 저장
	public void insertReRe(String recontent, int rref, int renum,int num) {
		getCon();
		int restep = 1;
		int relevel = 1;
		int a = relevel;
		try {
			String ssql = "select restep,relevel from re where renum=?";
			pstmt = con.prepareStatement(ssql);
			pstmt.setInt(1, renum);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				restep = rs.getInt(1);
				relevel = rs.getInt(2);
			}

			String sql = "update re set relevel=relevel+1 where rref=? and relevel>1 and restep=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, rref);
			pstmt.setInt(2, restep + 1);
			pstmt.executeUpdate();

			String isql = "insert into re(recontent,redate,rref,restep,relevel,boardnum) values(?,now(),?,?,?,?)";
			pstmt = con.prepareStatement(isql);
			pstmt.setString(1, recontent);
			pstmt.setInt(2, rref);
			pstmt.setInt(3, restep + 1);
			pstmt.setInt(4, a + 1);
			pstmt.setInt(5, num);

			pstmt.executeUpdate();

			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 댓글보기
	public Vector<ReBean> allRe(int num) {
		getCon();
		Vector<ReBean> v = new Vector<>();
		try {
			String sql = "select * from re where boardnum=? ORDER BY rref DESC, restep asc ,relevel asc ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ReBean bean = new ReBean();
				bean.setRenum(rs.getInt(1));
				bean.setRecontent(rs.getString(2));
				bean.setRedate(rs.getString(3));
				bean.setRref(rs.getInt(4));
				bean.setRestep(rs.getInt(5));
				bean.setRelevel(rs.getInt(6));
				v.add(bean);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}
}
