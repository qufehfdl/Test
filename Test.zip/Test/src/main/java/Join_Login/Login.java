package Join_Login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.MemberBean;
import Model.MemberDAO;

@WebServlet("/Login.do")
public class Login extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String id = request.getParameter("id"); // 입력받은 아이디
		String pw = request.getParameter("pw"); // 입력받은 패스워드

		MemberDAO mdao = new MemberDAO();
		MemberBean mBean = mdao.check(id);
		String cId = mBean.getId();	//DB에서 가져온 아이디
		String cPw = mBean.getPw(); //DB에서 가져온 패스워드
		
		if (id.equals(cId) && pw.equals(cPw)) {
			request.setAttribute("id", id);
			RequestDispatcher dis = request.getRequestDispatcher("BoardList.do");
			dis.forward(request, response); 
		}else {
			response.sendRedirect("LoginError.jsp");
		}

	}
}
