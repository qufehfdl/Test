package Controller.Re;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.BoardDAO;
import Model.ReDAO;

@WebServlet("/reWriteProc.do")
public class reWriteProc extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id"); // 접속자
		String recontent = request.getParameter("recontent");
		String n = request.getParameter("num"); // 게시글 번호
		ReDAO dao = new ReDAO();
		int num = Integer.parseInt(n);
		if (request.getParameter("r").equals("1")) {
			// a태그로 들어온 경우
			int rref = Integer.parseInt(request.getParameter("rref"));
			int renum = Integer.parseInt(request.getParameter("renum"));
			dao.insertReRe(recontent, rref, renum, num);

			request.setAttribute("id", id);
			request.setAttribute("num", num);
			RequestDispatcher dis = request.getRequestDispatcher("x2.jsp");
			dis.forward(request, response);
		} else {
			dao.insertRe(recontent, num);
			request.setAttribute("id", id);
			request.setAttribute("num", num);
			RequestDispatcher dis = request.getRequestDispatcher("x2.jsp");
			dis.forward(request, response);
		}
	}
}
