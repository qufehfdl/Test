package Controller.Re;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reWriteCon.do")
public class reWriteCon extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); 
		request.setAttribute("id", request.getParameter("id")); // 게시글 작성자
		request.setAttribute("id2", request.getParameter("id2")); // 접속자
		request.setAttribute("num", request.getParameter("num")); // 게시글 번호
		RequestDispatcher dis = request.getRequestDispatcher("reWriteBoard.jsp");
		dis.forward(request, response);
	}
}
