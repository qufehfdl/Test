package Controller.CRUD;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.BoardBean;
import Model.BoardDAO;
import Model.MemberBean;
import Model.MemberDAO;

@WebServlet("/WriteBoardProc.do")
public class WriteBoardProc extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		BoardDAO dao = new BoardDAO();
		BoardBean b = new BoardBean();
		b.setId(id);
		b.setSubject(subject);
		b.setContent(content);
		MemberDAO mdao = new MemberDAO();
		MemberBean mBean = mdao.check(id);
		String cId = mBean.getId(); // DB에서 가져온 아이디
		
		if (id.equals(cId)) {
			dao.insertBoard(b);
			request.setAttribute("id", id);
			RequestDispatcher dis = request.getRequestDispatcher("BoardList.do");
			dis.forward(request, response);

		} else { // 아니라면 에러페이지로
			request.setAttribute("id", id);
			RequestDispatcher dis = request.getRequestDispatcher("Error.jsp");
			dis.forward(request, response);
		}
	
	}
}
