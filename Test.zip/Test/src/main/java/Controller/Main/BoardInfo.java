package Controller.Main;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.BoardBean;
import Model.BoardDAO;
import Model.ReBean;
import Model.ReDAO;
import oracle.net.aso.b;

@WebServlet("/BoardInfo.do")
public class BoardInfo extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String num = request.getParameter("num"); // 글 번호
		String id2 = request.getParameter("id2"); // 현재 로그인 된 아이디

		int n = Integer.parseInt(num);
		request.setAttribute("id2", id2);
		// 원글의 게시글을 정보를 넘겨줌
		BoardDAO dao = new BoardDAO();
		BoardBean bean = dao.BoardInfo(n);
		request.setAttribute("num", bean.getNum());
		request.setAttribute("id", bean.getId()); // 작성자 아이디
		request.setAttribute("subject", bean.getSubject());
		request.setAttribute("content", bean.getContent());
		request.setAttribute("date", bean.getDate());
		request.setAttribute("readcount", bean.getReadCount());

		// 댓글의 정보를 넘기자
		ReDAO dao2 = new ReDAO();
		Vector<ReBean> v = dao2.allRe(bean.getNum());
		request.setAttribute("v", v);
		
		RequestDispatcher dis = request.getRequestDispatcher("BoardInfo.jsp");
		dis.forward(request, response);
	}
}