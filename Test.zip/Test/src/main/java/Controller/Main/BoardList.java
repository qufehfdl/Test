package Controller.Main;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.BoardBean;
import Model.BoardDAO;

@WebServlet("/BoardList.do")
public class BoardList extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		// -----------------------페이징 시작-------------------------
		// 화면에 보여질 개수를 지정
		int pageSize = 10;
		// 현재 보여지고 잇는 페이지의 넘버값을 읽어옴
		String pageNum = request.getParameter("pageNum");
		// 처음 들어오는 유저는 페이지 넘버가 없기때문에 null처리
		if (pageNum == null) {
			pageNum = "1";
		}
		// 전체 게시글의 갯수
		int count = 0;
		// jsp내에서 보여질 넘버링 숫자값을 저장하는 변수
		int number = 0;
		// 현재 보여지고 있는 페이지 문자를 숫자로 변환
		int currentPage = Integer.parseInt(pageNum);
		// 전체 게시글의 갯수를 가져와야 하기에 데이터베이스 객체 생성
		BoardDAO dao = new BoardDAO();
		count = dao.getAllCount();

		// 현재 보여질 페이지 시작 번호를 설정 : 몇개씩 끊어서 보여줄지 결정
		int startRow = (currentPage - 1) * pageSize + 1; // 2번째 페이지라면 11번 3번째 페이지라면 21번
		int endRow = currentPage * pageSize; // 2번째 페이지라면 20번 3번째 페이지라면 30번

		// 최신글 10개를 기준으로 게시글을 리턴 받아주는 메서드 호출
		Vector<BoardBean> v = dao.allBoard(startRow);
		// 화면에 보여질 number
		// 게시글이 11개 2페이지에는 1번글 , 게시글이 76개라면 4페이지에는 46번
		number = count - (currentPage - 1) * pageSize;
		request.setAttribute("v", v);
		request.setAttribute("number", number);
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("count", count);
		// -----------------------페이징 끝-------------------------
		
		System.out.println(request.getParameter("id"));
		String id = "";
		if (request.getParameter("id")== null ) {
			id = "손님";
		} else {
			id = request.getParameter("id");
		}
		request.setAttribute("id", id);
		
		RequestDispatcher dis = request.getRequestDispatcher("BoardList.jsp");
		dis.forward(request, response);
	}
}
