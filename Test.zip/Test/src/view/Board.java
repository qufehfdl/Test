package view;

import java.util.ArrayList;
import java.util.Scanner;

import Model.DAO;
import Model.bean;
import control.insert;

public class Board {

	public static void start() {
		insert in = new insert();
		DAO dao = new DAO();
		bean b = new bean();
		ArrayList<bean> aList = new ArrayList<>();

		int select = 0;
		Scanner sc = new Scanner(System.in);

		out: while (true) {
			System.out.println("■ 1.글 쓰기 ■ 2.글 목록 ■ 3.글 읽기 ■ 4.내용 수정 ■ 5.글 삭제 ■ 6.종료");
			try {
				select = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("다시 입력해 주세요");
				start();
			}

			switch (select) {
			case 1:
				b.setWriter(in.insertWriter());
				b.setSubject(in.insertSubject());
				b.setContent(in.insertContent());
				dao.insertBoard(b);
				break;
			case 2:
				aList = dao.boardList();
				for (int i = 0; i < aList.size(); i++) {
					b = aList.get(i);

					System.out.println("글 번호 : " + b.getNum() + " 작성자 : " + b.getWriter());
					System.out.println("제목 : " + b.getSubject() + " 작성 시간 : " + b.getDate());
					System.out.println("----------------------------------------");
				}
				break;
			case 3:
				try {
					System.out.println("글 번호를 입력해 주세요");
					Scanner sc1 = new Scanner(System.in);
					int num = sc1.nextInt();
					String content = dao.content(num);
					System.out.println("글 내용 : " + content);
				} catch (Exception e) {
					System.out.println("다시 입력해 주세요");
				}
				break;
			case 4:
				System.out.println("글 번호를 입력해 주세요");
				try {
					Scanner sc1 = new Scanner(System.in);
					int num = sc1.nextInt();
					String content = (in.insertContent());
					dao.update(num, content);
					System.out.println(num + "번 글이 수정되었습니다");
				} catch (Exception e) {
					System.out.println("다시 입력해 주세요");
				}

				break;
			case 5:
				System.out.println("글 번호를 입력해 주세요");
				try {
					Scanner sc1 = new Scanner(System.in);
					int num = sc1.nextInt();
					dao.delete(num);
					System.out.println(num + "번 글이 삭제되었습니다");
				} catch (Exception e) {
					System.out.println("다시 입력해 주세요");
				}
				break;
			case 6:
				break out;
			}
		} 
	}
}
