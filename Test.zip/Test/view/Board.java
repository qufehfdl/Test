package view;

import java.util.Scanner;
import java.util.Vector;

import Model.DAO;
import Model.bean;
import control.insert;

public class Board {

	public static void start() {
		DAO dao = new DAO();
		bean bean = new bean();
		int select = 0;
		out: while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("1.글 목록 | 2.글 쓰기 | 3.글 내용 | 4.글 수정 | 5.글 삭제 | 6.댓글 쓰기 | 7.종료");
			String num = sc.nextLine();
			if (num.equals("1") || num.equals("2") || num.equals("3") || num.equals("4") || num.equals("5")
					|| num.equals("6") || num.equals("7")) {
				select = Integer.parseInt(num);
			} else {
				System.out.println("다시 입력해 주세요");
				start();
			}
			switch (select) {
			case 1:
				// 부모글 리턴
				Vector<bean> v = dao.allBoard();
				// 답글 리턴
				Vector<bean> v2 = dao.reAllBoard();
				for (int i = 0; i < v.size(); i++) {
					bean b = v.get(i);

					System.out.println("글번호 :" + b.getNum() + "글 제목 : " + b.getWriter() + "글 내용 : " + b.getContent()
							+ "작성 시간 : " + b.getDate() + "조회수 : " + b.getReadcount());

					for (int j = 0; j < v2.size(); j++) {
						bean b2 = v2.get(j);
						if (b.getNum() == b2.getRef()) {
							System.out.println("[답글] : " + b2.getReContent() + " 작성자 : " + b2.getReWriter() + " 댓글번호 : "
									+ "[" + b2.getRenum() + "]");
						}
					}
				}
				break;
			case 2:
				insert in = new insert();
				bean.setWriter(in.insertWriter());
				bean.setSubject(in.insertSubject());
				bean.setContent(in.insertContent());
				dao.insertBoard(bean);
				break;
			case 3:
				System.out.println("글 번호를 입력해 주세요");
				try {
					int snum = sc.nextInt();
					String getContent = dao.oneContent(snum);
					System.out.println(getContent);
				} catch (Exception e) {
					System.out.println("다시 입력해 주세요");
				}
				break;
			case 4:
				System.out.println("글 번호를 입력해 주세요");
				int anum = sc.nextInt();
				System.out.println("1.글 제목 수정 || 2.글 내용 수정");
				try {
					int unum = sc.nextInt();
					if (unum == 1) {
						System.out.println("제목을 입력해 주세요");
						Scanner scc = new Scanner(System.in);
						String str = scc.nextLine();
						System.out.println("제목이 수정되었습니다");
						dao.updateSubject(anum, str);
					} else if (unum == 2) {
						System.out.println("내용을 입력해 주세요");
						Scanner scc = new Scanner(System.in);
						String str = scc.nextLine();
						System.out.println("내용이 수정되었습니다");
						dao.updateContent(anum, str);
					} else {
						System.out.println("다시 입력해 주세요");
						continue;
					}
				} catch (Exception e) {
					System.out.println("다시 입력해 주세요");
				}
				break;
			case 5:
				System.out.println("글 번호를 입력해 주세요");
				int dnum = sc.nextInt();
				dao.deleteBoard(dnum);
				System.out.println(dnum + "번 글이 삭제되었습니다");
				break;
			case 6:
				System.out.println("글 번호를 입력해 주세요");
				int rnum = sc.nextInt();
				insert in2 = new insert();
				bean.setReContent(in2.insertContent());
				bean.setReWriter(in2.insertWriter());
				dao.re(rnum, bean);

				break;
			case 7:
				System.out.println("종료합니다");
				break out;
			}
		}

	}
}
