package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.print.attribute.standard.JobPriority;
import javax.swing.Spring;

import control.insert;

public class DAO {

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taehwa", "root", "1042");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	// 하나의 게시글을 저장하는 메서드
	public void insertBoard(bean bean) {
		getCon();
		int ref = 0;
		int re_step = 1;
		int re_level = 1;
		try {
			String refsql = "select max(ref) from board ";
			pstmt = con.prepareStatement(refsql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ref = rs.getInt(1) + 1;
			}
			String sql = "insert into board(subject,writer,content,readcount,date,ref,re_step,re_level)values(?,?,?,0,now(),?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getSubject());
			pstmt.setString(2, bean.getWriter());
			pstmt.setString(3, bean.getContent());
			pstmt.setInt(4, ref);
			pstmt.setInt(5, re_step);
			pstmt.setInt(6, re_level);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 전체 게시글을 리턴
	public Vector<bean> allBoard() {
		Vector<bean> v = new Vector<>();
		getCon();
		try {
			String sql = "select * from board where subject is not null";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bean b = new bean();
				b.setNum(rs.getInt(1));
				b.setSubject(rs.getString(2));
				b.setWriter(rs.getString(3));
				b.setContent(rs.getString(4));
				b.setReadcount(rs.getInt(5));
				b.setDate(rs.getString(6));
				b.setRef(rs.getInt(7));
				b.setRe_step(rs.getInt(8));
				b.setRe_level(rs.getInt(9));
				v.add(b);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}

	// 글 내용 반환
	public String oneContent(int num) {
		getCon();
		String content = "";
		try {
			String sql = "select content from board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				content = rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}

	public void updateSubject(int num, String str) {
		getCon();
		try {
			String sql = "update board set subject=? where num=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, str);
			pstmt.setInt(2, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateContent(int num, String str) {
		getCon();
		try {
			String sql = "update board set content=? where num=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, str);
			pstmt.setInt(2, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteBoard(int num) {
		getCon();
		try {
			String sql = "delete from board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 부모글을 리턴받아 댓글저장
	public void re(int num, bean b) {
		getCon();
		try {
			// 부모에 값을 bean에 세팅
			bean pb = new bean();
			String parentsql = "select ref,re_step,re_level from board where num=?";
			pstmt = con.prepareStatement(parentsql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				pb.setRef(rs.getInt(1));
				pb.setRe_step(rs.getInt(2));
				pb.setRe_level(rs.getInt(3));
			}
			// 부모글그룹과 같은 글그룹글들을 level 1씩 증가시킴
			String usql = "update board set re_level = re_level+1 where ref=? and re_level>?";
			pstmt = con.prepareStatement(usql);
			pstmt.setInt(1, pb.getRef());
			pstmt.setInt(2, pb.getRe_level());
			pstmt.executeUpdate();

			int maxRenum = 0;
			String maxsql = "select max(renum) from board";
			pstmt = con.prepareStatement(maxsql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				maxRenum = rs.getInt(1);
			}

			String sql = "insert into board(ref,re_step,re_level,renum,rewriter,recontent) values(?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, pb.getRef());
			pstmt.setInt(2, pb.getRe_step() + 1);
			pstmt.setInt(3, pb.getRe_level() + 1);
			pstmt.setInt(4, maxRenum + 1);
			pstmt.setString(5, b.getReWriter());
			pstmt.setString(6, b.getReContent());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 부모의 글번호를 받아서 답글을 리턴
	public Vector<bean> reAllBoard() {
		getCon();
		Vector<bean> v = new Vector<>();
		try {
			String sql = "select ref,recontent,rewriter,renum from board where subject is null and re_step>1 order by re_level";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bean b = new bean();
				b.setRef(rs.getInt(1));
				b.setReContent(rs.getString(2));
				b.setReWriter(rs.getString(3));
				b.setRenum(rs.getInt(4));
				v.add(b);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}
}
